#include <cmath>
using namespace std;

double Sgn(double a,double b){ 
  return (b<0)?-abs(a):abs(a);
}
